// ignore_for_file: deprecated_member_use

import 'dart:ui';

import 'package:flutter/material.dart';

class Mycolor {
  static const black = Color(0xff000000);
  static const white = Color(0xffffffff);
  static const lightgrey = Color(0xffECF0F1);
  static const primarycolor = Color(0xff2ECC71);
  static const grey = Color(0xff7A7A7A);
}
