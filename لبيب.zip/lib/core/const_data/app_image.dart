class AppImage {
//image
  static const String imagesRoot = "assets/image";

//root
  static const String iconRoot = "assets/icon";
}
